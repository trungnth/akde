#!/bin/sh

myos=`uname -o`
rm -rvf build-* mingw-* linux freebsd

if hash mingw64-cmake 2> /dev/null
    then \
    mingw64-cmake -S . -B build-64 -DCMAKE_INSTALL_PREFIX=$PWD/mingw-64 -DCMAKE_INSTALL_LIBDIR=$PWD/mingw-64/lib -DCMAKE_BUILD_TYPE=Release
    cmake --build build-64 --target install || exit 1
fi

if [ "${myos}" == "GNU/Linux" ]
    then \
    cmake -S . -B build-linux -DCMAKE_INSTALL_PREFIX=$PWD/linux -DCMAKE_BUILD_TYPE=Release
    cmake --build build-linux --target install || exit 3
fi

if [ "${myos}" == "FreeBSD" ]
   then \
    cmake -S . -B build-freebsd -DCMAKE_INSTALL_PREFIX=$PWD/freebsd -DCMAKE_BUILD_TYPE=Release
    cmake --build build-freebsd --target install || exit 3
fi
